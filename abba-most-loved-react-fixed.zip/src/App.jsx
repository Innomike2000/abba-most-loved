import React from 'react'

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '100px' }}>
      <h1>🔥 Abba’s Most Loved is Live!</h1>
      <p>Welcome to your spirit-filled ministry hub online.</p>
    </div>
  )
}

export default App
